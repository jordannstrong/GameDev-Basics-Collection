TEAM NAME
: Macro Jr.


Members:
Jordan Strong strongj1@students.rowan.edu


Ryan Lindsay Lindsa48@students.rowan.edu


Marcus Moss mossm7@students.rowan.edu





Games (Design Changes):

Egg Drop: Added gold eggs, greens eggs, shiny eggs and rocks (see How To Play to learn what they do), as well as a multi-purpose spawner

to randomly spawn everything. Retextured the ground and hills.



Infinite Jumper: Replaced the default player model with a baby dragon and added the ability to swap between hats (for different effects)

or remove them altogether. Also adjusted the bottom boundary detection so that the player character can stand on platforms at the bottom

of the screen without "dying".



Marble Runner: Added new levels, more types of gems (they don't do anything special, they mostly just add more of a challenge to 
completing the levels due to being included in the required total), gem spinning animation, a camera that can be rotated with the mouse, 
moving platforms, a jump function, 
and new textures. Rotating the camera re-orients the player controls so that the direction the camera 
is facing is always "forward".



Games (How To Play):

Egg Drop:

Score at least 50 points before the timer runs out.

A/<-: Move left
D/->: Move right
	
	Normal eggs: 1 point

	Gold eggs: 5 points

	Rocks: -5 points

	Shiny eggs: Extra time

	Green Eggs: Big bucket



Infinite Jumper:

Get as high as you can without falling off.

A/<-: Move left
D/->: Move right

1: Top Hat

2: Viking Helm

3: No Hat

	Hats:

	Top Hat: Dapper Dragon (No special effects)

	Viking Helm: Flying Dragon (Double Jump)



Marble Runner:

Collect all of the gems to complete each level.

W: Roll Forward

A: Roll Left
S: Roll Backward

D: Roll Right
SPACE: Jump

LMB & Drag: Rotate Camera